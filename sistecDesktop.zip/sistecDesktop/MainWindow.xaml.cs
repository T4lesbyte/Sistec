﻿using sistecDesktop.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Converters;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace sistecDesktop
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            MainContent.Content = new LoginView();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }

        //Estilização do passwordbox
        #region
        private void txbForgotPass_MouseEnter(object sender, MouseEventArgs e)
        {
            var tb = sender as TextBlock;

            this.Cursor = Cursors.Hand;
            tb.TextDecorations = TextDecorations.Underline;
        }

        private void txbForgotPass_MouseLeave(object sender, MouseEventArgs e)
        {
            var tb = sender as TextBlock;

            this.Cursor = Cursors.Arrow;
            tb.TextDecorations = default;
        }

        private void txbForgotPass_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            var tb = sender as TextBlock;

            tb.Foreground = (Brush)Application.Current.Resources["brush-tropicalIndigo"];
        }

        private void txbForgotPass_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            var tb = sender as TextBlock;

            tb.Foreground = (Brush)Application.Current.Resources["brush-vibrantViolet"];
        }

        #endregion


        //Estilização do botão Entrar
        #region
        private void brdBtnEnter_MouseEnter(object sender, MouseEventArgs e)
        {
            var pb = sender as Border;

            this.Cursor = Cursors.Hand;
        }

        private void brdBtnEnter_MouseLeave(object sender, MouseEventArgs e)
        {
            var pb = sender as Border;

            this.Cursor = Cursors.Arrow;
            
        }

        private void brdBtnEnter_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            var pb = sender as Border;

            pb.Background = (Brush)Application.Current.Resources["brush-tropicalIndigo"];
        }

        private void brdBtnEnter_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            var pb = sender as Border;

            pb.Background = (Brush)Application.Current.Resources["brush-vibrantViolet"];
        }

        #endregion
    }
}
